function SpawnPoints()
    return {
     
      constructionworker = { 
      { worldX = 37, worldY = 25, posX = 11250, posY = 7502, posZ = 0 },
      },
    
      fireofficer = { 
      { worldX = 37, worldY = 25, posX = 11373, posY = 7674, posZ = 0 }, 
      },
      
      parkranger = { 
      { worldX = 37, worldY = 25, posX = 11373, posY = 7674, posZ = 0 }, 
      },
    
      policeofficer = {
      { worldX = 37, worldY = 25, posX = 11325, posY = 7536, posZ = 0 }, 
      },
    
      securityguard = {
      { worldX = 37, worldY = 25, posX = 11309, posY = 7768, posZ = 0 }, 
      },
    
      unemployed = { 
      { worldX = 37, worldY = 25, posX = 11309, posY = 7768, posZ = 0 }, 
	  { worldX = 37, worldY = 25, posX = 11373, posY = 7674, posZ = 0 }, 
      },    	  
       
 
    }
    
    end