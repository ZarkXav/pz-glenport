function SpawnPoints()
    return {
     
      constructionworker = { 
      { worldX = 37, worldY = 25, posX = 150, posY = 2, posZ = 0 },
	  { worldX = 37, worldY = 25, posX = 274, posY = 175, posZ = 0 }, 
	  { worldX = 37, worldY = 25, posX = 210, posY = 266, posZ = 0 }, 
      },
    
      fireofficer = { 
      { worldX = 37, worldY = 25, posX = 274, posY = 175, posZ = 0 }, 
	  { worldX = 37, worldY = 25, posX = 210, posY = 266, posZ = 0 }, 
      },
      
      parkranger = { 
      { worldX = 37, worldY = 25, posX = 274, posY = 175, posZ = 0 }, 
	  { worldX = 37, worldY = 25, posX = 210, posY = 266, posZ = 0 }, 
      },
    
      policeofficer = {
      { worldX = 37, worldY = 25, posX = 222, posY = 34, posZ = 0 },
      { worldX = 37, worldY = 25, posX = 274, posY = 175, posZ = 0 }, 
	  { worldX = 37, worldY = 25, posX = 210, posY = 266, posZ = 0 }, 
      },
    
      securityguard = {
      { worldX = 37, worldY = 25, posX = 274, posY = 175, posZ = 0 }, 
	  { worldX = 37, worldY = 25, posX = 210, posY = 266, posZ = 0 }, 
      },
    
      unemployed = { 
      { worldX = 37, worldY = 25, posX = 274, posY = 175, posZ = 0 }, 
	  { worldX = 37, worldY = 25, posX = 210, posY = 266, posZ = 0 }, 
      },    	  
       
 
    }
    
    end